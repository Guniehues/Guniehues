import java.util.HashSet;
import java.util.Scanner;

public class Cliente implements Modulacao {

    private String nome;
    private String telefone;
    private String rg;
    private String cpf;
    private String email;

    private static HashSet<Cliente> Clientes = new HashSet<>();
    Scanner input = new Scanner(System.in);

    public Cliente() {
        
    }





    protected String getNome() {
        return nome;
    }

    protected void setNome(String nome) {
        this.nome = nome;
    }

    protected String getTelefone() {
        return telefone;
    }

    protected void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    protected String getRg() {
        return rg;
    }

    protected void setRg(String rg) {
        this.rg = rg;
    }

    protected String getCpf() {
        return cpf;
    }

    protected void setCpf(String cpf) {
        this.cpf = cpf;
    }

    protected String getEmail() {
        return email;
    }

    protected void setEmail(String email) {
        this.email = email;
    }



    private void _espaço() {
        for (int i = 0; i < 3; i++) {
            System.out.println("");
        }
    }




    static Cliente _Buscalista(String cpf) {

        if (Clientes.isEmpty()) {
            System.out.println("Nenhum cliente cadastrado.");
            return null;    
        }

        else {
            for (Cliente cliente : Clientes) {
                if (cliente.getCpf().equals(cpf)) {
                    return  cliente;
                }
            }

            return null;
        }
    }
   


    @Override
    public void Cadastro() {
        
        System.out.println("----- Cadastro de Clientes -----");
        System.out.println("");

        Cliente novoCliente = new Cliente();

        System.out.println("Digite o nome: ");
        nome = input.nextLine();
        novoCliente.setNome(nome);

        System.out.println("Digite o telefone: ");
        telefone = input.nextLine();
        novoCliente.setTelefone(telefone);

        System.out.println("Digite o RG: ");
        rg = input.nextLine();
        novoCliente.setRg(rg);

        System.out.println("Digite o CPF: ");
        cpf = input.nextLine();
        novoCliente.setCpf(cpf);

        System.out.println("Digite o email: ");
        email = input.nextLine();
        novoCliente.setEmail(email);

        Clientes.add(novoCliente);
        System.out.println("Cadastro realizado com sucesso!!!");
        _espaço();
    }

    @Override
    public void Consulta() {

        System.out.println("----- Consulta de Clientes -----");
        System.out.println("Digite o CPF a ser consultado:");
        String cpfConsulta = input.nextLine();
        _espaço();

        Cliente Busca = _Buscalista(cpfConsulta);
        if (Busca != null) {
                System.out.println("Cliente encontrado!!!");
                System.out.println("========================");
                System.out.println("Nome: " + Busca.getNome());
                System.out.println("Telefone: " + Busca.getTelefone());
                System.out.println("RG: " + Busca.getRg());
                System.out.println("CPF: " + Busca.getCpf());
                System.out.println("Email: " + Busca.getEmail());
                System.out.println("========================");
                _espaço();
        }

        else {
                System.out.println("Cliente não cadastrado!!!");
                _espaço();
            }

        }
    
    

    @Override
    public void Alterar() {
        System.out.println("----- Alteração de Clientes -----");
        System.out.println("Digite o CPF para a busca:");
        String cpfConsulta = input.nextLine();
        _espaço();

        Cliente Busca = _Buscalista(cpfConsulta);
        if (Busca != null) {
                System.out.println("Cliente encontrado!!!");

                while (true) {

                System.out.println("Qual dado vc deseja alterar? \n" +  
                "1 - Nome\n" +
                "2 - Telefone\n" +
                "3 - RG\n" +
                "4 - Email\n" +
                "5 - CPF\n" +
                "6 - Sair");
                _espaço();

                int escolha = input.nextInt();
                input.nextLine();




                if (escolha == 1) {
                    System.out.println("Digite o novo nome: ");
                    String novoNome = input.nextLine();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        Busca.setNome(novoNome);
                        System.out.println("Nome alterado com sucesso!!!");
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                    }

                    _espaço();

                }




                else if (escolha == 2) {
                    System.out.println("Digite o novo telefone: ");
                    String novoTelefone = input.nextLine();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        Busca.setTelefone(novoTelefone);
                        System.out.println("Telefone alterado com sucesso!!!");
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                    }

                    _espaço();

                }





                else if (escolha == 3) {
                    System.out.println("Digite o novo RG: ");
                    String novoRg = input.nextLine();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        Busca.setRg(novoRg);
                        System.out.println("RG alterado com sucesso!!!");
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                    }

                    _espaço();
                }





                else if (escolha == 4) {
                    System.out.println("Digite o novo email: ");
                    String novoEmail = input.nextLine();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        Busca.setEmail(novoEmail);
                        System.out.println("Email alterado com sucesso!!!");
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                    }    

                    _espaço();
                }


                else if (escolha == 5) {
                    System.out.println("Digite o novo CPF: ");
                    String novoCpf = input.nextLine();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        Busca.setCpf(novoCpf);
                        System.out.println("CPF alterado com sucesso!!!");
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                    }

                    _espaço();
                }



                else if (escolha == 6) {
                    System.out.println("Saindo do menu de alteração...");
                    _espaço();
                    break;
                    
                }

                else {
                    System.out.println("Opção inválida!!!");
                    _espaço();
                    break;

                }

                
            }
        }

        else {
                System.out.println("Cliente não cadastrado!!!");
                _espaço();
            }

    }
        
    

    @Override
    public void Remocao() {
        
        System.out.println("----- Remoção de Clientes -----");
        System.out.println("Digite o CPF para a busca:");
        String cpfConsulta = input.nextLine();
        _espaço();

        Cliente Busca = _Buscalista(cpfConsulta);
        if (Busca != null) {
                System.out.println("Cliente encontrado!!!");
                System.out.println("Confirma a remoção(s/n)?");
                String confirma = input.nextLine();

                if (confirma.equals("s")){ 
                    Clientes.remove(Busca);
                    System.out.println("Cliente removido com sucesso!!!");
                }
                else {
                    System.out.println("Remoção cancelada!!!");
                }

                _espaço();    
        }

        else {
                System.out.println("Cliente não cadastrado!!!");
                _espaço();
            }

    }      

    @Override
    public void Listar() {
        System.out.println("----- Lista de Clientes -----");
        System.out.println("");

        if (Clientes.isEmpty()) {
            System.out.println("Nenhum cliente cadastrado.");
            _espaço();
        }

        else {
            for (Cliente cliente : Clientes) {
                System.out.println("========================");
                System.out.println("Nome: " + cliente.getNome());
                System.out.println("Telefone: " + cliente.getTelefone());
                System.out.println("RG: " + cliente.getRg());
                System.out.println("CPF: " + cliente.getCpf());
                System.out.println("Email: " + cliente.getEmail());
                System.out.println("========================");
                _espaço();
            }
        }
    }


}





