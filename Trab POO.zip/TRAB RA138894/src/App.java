import java.util.Scanner;

public class App {

    private static void _espaço() {
        System.out.println("");
    }
    public static void main(String[] args) throws Exception {
        
        Cliente aba_Cliente = new Cliente();
        Funcionario aba_Funcionario = new Funcionario();
        Veiculo aba_Veiculo = new Veiculo();
        Venda aba_Venda = new Venda();
        Scanner input = new Scanner(System.in);

        System.out.println("----- Bem-vindo ao Sistema da Concessionária -----");
        System.out.println("");
        System.out.println("Escolha a aba que deseja acessar:");
        System.out.println("1 - Cliente"
                         + "\n2 - Funcionário"
                         + "\n3 - Veículo"
                         + "\n4 - Venda"
                         + "\n0 - Sair do sistema");
        
        int escolha = input.nextInt();
        input.nextLine();
        _espaço();

        while( (escolha > 0) || (escolha < 5)) {

            if (escolha == 1) {

                while (true) {
                    System.out.println("----- Aba Clientes -----");
                    System.out.println("");

                    System.out.println("Escolha a operação que deseja realizar:\n" +
                                    "1 - Cadastrar Cliente\n" +
                                    "2 - Consultar Cliente\n" +
                                    "3 - Alterar Cliente\n" +
                                    "4 - Excluir Cliente\n" +
                                    "5 - Listar Clientes\n" +
                                    "6 - Voltar ao menu principal");

                    int op = input.nextInt();
                    input.nextLine();
                    _espaço();
                    
                    if (op == 1) {
                        aba_Cliente.Cadastro();
                    }

                    else if (op == 2) {
                        aba_Cliente.Consulta();
                    }

                    else if (op == 3) {
                        aba_Cliente.Alterar();
                    }

                    else if (op == 4) {
                        aba_Cliente.Remocao();
                    }

                    else if (op == 5) {
                        aba_Cliente.Listar();
                    }

                    else {
                        System.out.println("Voltando ao menu principal...");
                        _espaço();
                        break;
                    }

                    _espaço();
                    }
            }




            else if (escolha == 2) {

                while (true) {
                    System.out.println("----- Aba Funcionários -----");
                    System.out.println("");

                    System.out.println("Escolha a operação que deseja realizar:\n" +
                                    "1 - Cadastrar Funcionário\n" +
                                    "2 - Consultar Funcionário\n" +
                                    "3 - Alterar Funcionário\n" +
                                    "4 - Excluir Funcionário\n" +
                                    "5 - Listar Funcionários\n" +
                                    "6 - Voltar ao menu principal");
                    
                    int op = input.nextInt();
                    input.nextLine();
                    _espaço();
                    
                    if (op == 1) {
                        aba_Funcionario.Cadastro();
                    }

                    else if (op == 2) {
                        aba_Funcionario.Consulta();
                    }

                    else if (op == 3) {
                        aba_Funcionario.Alterar();
                    }

                    else if (op == 4) {
                        aba_Funcionario.Remocao();
                    }

                    else if (op == 5) {
                        aba_Funcionario.Listar();
                    }

                    else {
                        System.out.println("Voltando ao menu principal...");
                        _espaço();
                        break;
                    }

                    _espaço();
                }

            }





            else if (escolha == 3) {

                while (true){
                    System.out.println("----- Aba Veículos -----");
                    System.out.println("");

                    System.out.println("Escolha a operação que deseja realizar:\n" +
                                    "1 - Cadastrar Veículo\n" +
                                    "2 - Consultar Veículo\n" +
                                    "3 - Alterar Veículo\n" +
                                    "4 - Excluir Veículo\n" +
                                    "5 - Listar Veículos\n" +
                                    "6 - Voltar ao menu principal");
                    int op = input.nextInt();
                    input.nextLine();
                    _espaço();

                    if (op == 1) {
                        aba_Veiculo.Cadastro();
                    }

                    else if (op == 2) {
                        aba_Veiculo.Consulta();
                    }

                    else if (op == 3) {
                        aba_Veiculo.Alterar();
                    }

                    else if (op == 4) {
                        aba_Veiculo.Remocao();
                    }

                    else if (op == 5) {
                        aba_Veiculo.Listar();
                    }

                    else {
                        System.out.println("Voltando ao menu principal...");
                        _espaço();
                        break;
                    }

                    _espaço();
                }
            }





            else if (escolha == 4) {

                while (true) {
                    System.out.println("----- Aba Vendas -----");
                    System.out.println("");

                    System.out.println("Escolha a operação que deseja realizar:\n" +
                                    "1 - Cadastrar Venda\n" +
                                    "2 - Consultar Venda\n" +
                                    "3 - Alterar Venda\n" +
                                    "4 - Excluir Venda\n" +
                                    "5 - Listar Vendas\n" +
                                    "6 - Voltar ao menu principal");

                    int op = input.nextInt();
                    input.nextLine();
                    _espaço();

                    if (op == 1) {
                        aba_Venda.Cadastro();
                    }

                    else if (op == 2) {
                        aba_Venda.Consulta();
                    }

                    else if (op == 3) {
                        aba_Venda.Alterar();
                    }

                    else if (op == 4) {
                        aba_Venda.Remocao();
                    }

                    else if (op == 5) {
                        aba_Venda.Listar();
                    }

                    else {
                        System.out.println("Voltando ao menu principal...");
                        escolha = 0;
                        _espaço();
                        break;
                    }

                    _espaço();
                }
            }






            else {
                System.out.println("Deseja sair do sistema? (s/n)");
                String sair = input.nextLine();

                if (sair.equals("s")) {
                    System.out.println("Saindo do sistema...");
                    break;
                }

                else {
                    System.out.println("Voltando ao menu principal...");
                    _espaço();
                }
            }


            _espaço();
            System.out.println("----- Bem-vindo ao Sistema da Concessionária -----");
            System.out.println("");
            System.out.println("Escolha a aba que deseja acessar:");
            System.out.println("1 - Cliente"
                            + "\n2 - Funcionário"
                            + "\n3 - Veículo"
                            + "\n4 - Venda"
                            + "\n0 - Sair do sistema");
            
            escolha = input.nextInt();
            input.nextLine();
            _espaço();


    }
        input.close();
    } 
}
