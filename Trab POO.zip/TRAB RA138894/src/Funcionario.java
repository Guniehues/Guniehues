import java.util.HashSet;
import java.util.Scanner;

public class Funcionario implements Modulacao {

    private String nome;
    private int numMatricula;
    private String qualificacao;
    private String funcao;
    private int cargaHoraria;


    Scanner input = new Scanner(System.in);
    private static HashSet<Funcionario> Funcionarios = new HashSet<>();


    public Funcionario() {
        
    }



    protected String getNome() {
        return nome;
    }

    protected void setNome(String nome) {
        this.nome = nome;
    }

    protected int getNumMatricula() {
        return numMatricula;
    }

    protected void setNumMatricula(int numMatricula) {
        this.numMatricula = numMatricula;
    }

    protected String getQualificacao() {
        return qualificacao;
    }

    protected void setQualificacao(String qualificacao) {
        this.qualificacao = qualificacao;
    }

    protected String getFuncao() {
        return funcao;
    }

    protected void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    protected int getCargaHoraria() {
        return cargaHoraria;
    }

    protected void setCargaHoraria(int cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }


    private void _espaço() {
        for (int i = 0; i < 3; i++) {
            System.out.println("");
        }
    }


    static Funcionario _Buscalista(int matricula) {

        if (Funcionarios.isEmpty()) {
            System.out.println("Nenhum cliente cadastrado.");
            return null;    
        }
        
        else {
            for (Funcionario funcionario : Funcionarios) {
                if (funcionario.getNumMatricula() == matricula) {
                    return  funcionario;
                }
            }

            return null;
        }
    }





    @Override
    public void Cadastro() {

        System.out.println("----- Cadastro de Funcionários -----");
        System.out.println("");

        Funcionario novoFuncionario = new Funcionario();
        
        System.out.println("Digite o nome do funcionário: ");
        nome = input.nextLine();
        novoFuncionario.setNome(nome);

        System.out.println("Digite o número de matrícula: ");
        numMatricula = input.nextInt();
        input.nextLine();
        novoFuncionario.setNumMatricula(numMatricula);

        System.out.println("Digite a qualificação: ");
        qualificacao = input.nextLine();
        novoFuncionario.setQualificacao(qualificacao);

        System.out.println("Digite a função: ");
        funcao = input.nextLine();
        novoFuncionario.setFuncao(funcao);

        System.out.println("Digite a carga horária: ");
        cargaHoraria = input.nextInt();
        input.nextLine();
        novoFuncionario.setCargaHoraria(cargaHoraria);

        Funcionarios.add(novoFuncionario);
        System.out.println("Funcionário cadastrado com sucesso!!!");
        _espaço();
        
    }

    @Override
    public void Consulta() {
        
        System.out.println("----- Consulta de Funcionários -----");
        System.out.println("Digite o número da matrícula a ser consultado:");
        int matriculaConsulta = input.nextInt();
        input.nextLine();
        _espaço();

        Funcionario Busca = _Buscalista(matriculaConsulta);
        if (Busca != null) {
                System.out.println("Funcionário encontrado!!!");
                System.out.println("");
                System.out.println("========================");
                System.out.println("Nome: " + Busca.getNome());
                System.out.println("Número de Matrícula: " + Busca.getNumMatricula());
                System.out.println("Qualificação: " + Busca.getQualificacao());
                System.out.println("Função: " + Busca.getFuncao());
                System.out.println("Carga Horária: " + Busca.getCargaHoraria());
                System.out.println("========================\n");
                _espaço();
        }

        else {
                System.out.println("Funcionário não cadastrado!!!");
                _espaço();
            }

        }
        
    

    @Override
    public void Alterar() {
        
        System.out.println("----- Alteração de Funcionários -----");
        System.out.println("Digite o número da matrícula a ser consultado:");
        int matriculaConsulta = input.nextInt();
        input.nextLine();
        _espaço();


        Funcionario Busca = _Buscalista(matriculaConsulta);
        if (Busca != null) {
                System.out.println("Funcionário encontrado!!!");

                while (true) {

                System.out.println("Qual dado vc deseja alterar? \n" +  
                "1 - Nome\n" +
                "2 - Número Matrícula\n" +
                "3 - Qualificação\n" +
                "4 - Função\n" +
                "5 - Carga Horário\n" +
                "6 - Sair");

                int escolha = input.nextInt();
                input.nextLine();
                _espaço();



                if (escolha == 1) {
                    System.out.println("Digite o novo nome: ");
                    String novoNome = input.nextLine();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        Busca.setNome(novoNome);
                        System.out.println("Nome alterado com sucesso!!!");
                        _espaço();
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                        _espaço();
                        
                    }
                }




                else if (escolha == 2) {
                    System.out.println("Digite o novo número de matrícula: ");
                    int novonumMatricula = input.nextInt();
                    input.nextLine();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        Busca.setNumMatricula(novonumMatricula);
                        System.out.println("Número de matrícula alterado com sucesso!!!");
                        _espaço();
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                        _espaço();
                    }
                }





                else if (escolha == 3) {
                    System.out.println("Digite a nova qualificação: ");
                    String novaqualificação = input.nextLine();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        Busca.setQualificacao(novaqualificação);
                        System.out.println("qualificação alterado com sucesso!!!");
                        _espaço();
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                        _espaço();
                    }
                }





                else if (escolha == 4) {
                    System.out.println("Digite a nova função: ");
                    String novofunção = input.nextLine();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        Busca.setFuncao(novofunção);
                        System.out.println("Função alterada com sucesso!!!");
                        _espaço();
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                        _espaço();
                    }    
                }


                else if (escolha == 5) {
                    System.out.println("Digite a nova carga horária: ");
                    int novacargaHoraria = input.nextInt();
                    input.nextLine();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        Busca.setCargaHoraria(novacargaHoraria);
                        System.out.println("Carga horária alterada com sucesso!!!");
                        _espaço();
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                        _espaço();
                    }    
                }


                else if (escolha == 6) {
                    System.out.println("Saindo do menu de alteração...");
                    _espaço();
                    break;
                }

                else {
                    System.out.println("Opção inválida!!!");
                    _espaço();
                    break;
                }

                
            }
        }

        else {
                System.out.println("Funcionário não cadastrado!!!");
                _espaço();
            }

    }
        
    

    @Override
    public void Remocao() {
        
        System.out.println("----- Remoção de Funcionários -----");
        System.out.println("Digite o numéro da matrícula para a busca:");
        int matriculaConsulta = input.nextInt();
        input.nextLine();
        _espaço();

        Funcionario Busca = _Buscalista(matriculaConsulta);
        if (Busca != null) {
                System.out.println("Funcionário encontrado!!!");
                System.out.println("Confirma a remoção(s/n)?");
                String confirma = input.nextLine();

                if (confirma.equals("s")){ 
                    Funcionarios.remove(Busca);
                    System.out.println("Funcionário removido com sucesso!!!");
                }
                else {
                    System.out.println("Remoção cancelada!!!");
                }    

                _espaço();
        }

        else {
                System.out.println("Funcionário não cadastrado!!!");
                _espaço();
            }

    }


    @Override
    public void Listar() {
        System.out.println("----- Lista de Funcionários -----");
        System.out.println("");
        if (Funcionarios.isEmpty()) {
            System.out.println("Nenhum funcionário cadastrado!!!");
            _espaço();
        }
        else {
            for (Funcionario funcionario : Funcionarios) {
                System.out.println("========================");
                System.out.println("Nome: " + funcionario.getNome());
                System.out.println("Número de Matrícula: " + funcionario.getNumMatricula());
                System.out.println("Qualificação: " + funcionario.getQualificacao());
                System.out.println("Função: " + funcionario.getFuncao());
                System.out.println("Carga Horária: " + funcionario.getCargaHoraria());
                System.out.println("========================\n");
                _espaço();
            }
            _espaço();
        }
    }


}
