interface Modulacao {
    
    public abstract void Cadastro();
    public abstract void Consulta();
    public abstract void Alterar();
    public abstract void Remocao();
    public abstract void Listar();

}
