import java.util.HashSet;
import java.util.Scanner;

public class Veiculo implements Modulacao {
    
    private String nome;
    private String cor;
    private int numMarchas;
    private int numPortas;
    private String marca;
    private int ano;
    private String numChassi;
    

    Scanner input = new Scanner(System.in);
    private static HashSet<Veiculo> Veiculos = new HashSet<>();

    
    public Veiculo() {
        
    }


    protected String getNome() {
        return nome;
    }

    protected void setNome(String nome) {
        this.nome = nome;
    }

    protected String getCor() {
        return cor;
    }

    protected void setCor(String cor) {
        this.cor = cor;
    }

    protected int getNumMarchas() {
        return numMarchas;
    }

    protected void setNumMarchas(int numMarchas) {
        this.numMarchas = numMarchas;
    }

    protected int getNumPortas() {
        return numPortas;
    }

    protected void setNumPortas(int numPortas) {
        this.numPortas = numPortas;
    }

    protected String getMarca() {
        return marca;
    }

    protected void setMarca(String marca) {
        this.marca = marca;
    }

    protected int getAno() {
        return ano;
    }

    protected void setAno(int ano) {
        this.ano = ano;
    }

    protected String getNumChassi() {
        return numChassi;
    }

    protected void setNumChassi(String numChassi) {
        this.numChassi = numChassi;
    }


    private void _espaço() {
        for (int i = 0; i < 3; i++) {
            System.out.println("");
        }
    }


    static Veiculo _Buscalista(String nchassi) {

        if (Veiculos.isEmpty()) {
            System.out.println("Nenhum carro cadastrado!!!");
            return null;    
        }

        else {
            for (Veiculo veiculo : Veiculos) {
                if (veiculo.getNumChassi().equals(nchassi)) {
                    return  veiculo;
                }
            }

            return null;
        }
    }



    @Override
    public void Cadastro() {

        System.out.println("----- Cadastro de Veículos -----");
        System.out.println("");
        Veiculo novoVeiculo = new Veiculo();

        System.out.print("Digite o número do chassi do veículo: ");
        numChassi = input.nextLine();
        novoVeiculo.setNumChassi(numChassi);

        System.out.print("Digite o nome do veículo: ");
        nome = input.nextLine();
        novoVeiculo.setNome(nome);

        System.out.print("Digite a cor do veículo: ");
        cor = input.nextLine();
        novoVeiculo.setCor(cor);

        System.out.print("Digite o número de marchas do veículo: ");
        numMarchas = input.nextInt();
        input.nextLine();
        novoVeiculo.setNumMarchas(numMarchas);

        System.out.print("Digite o número de portas do veículo: ");
        numPortas = input.nextInt();
        input.nextLine();
        novoVeiculo.setNumPortas(numPortas);
        

        System.out.print("Digite a marca do veículo: ");
        marca = input.nextLine();
        novoVeiculo.setMarca(marca);

        System.out.print("Digite o ano do veículo: ");
        ano = input.nextInt();
        input.nextLine();
        novoVeiculo.setAno(ano);

        Veiculos.add(novoVeiculo);
        System.out.println("Veículo cadastrado com sucesso!!!");
        _espaço();
    }

    @Override
    public void Consulta() {
        
        System.out.println("----- Consulta de Veículos -----");
        System.out.println("Digite o número do chassi a ser consultado:");
        String chassiConsulta = input.nextLine();
        _espaço();

        Veiculo Busca = _Buscalista(chassiConsulta);
        if (Busca != null) {
                System.out.println("Veículo encontrado!!!");
                System.out.println("");
                System.out.println("========================");
                System.out.println("Número do Chassi: " + Busca.getNumChassi());
                System.out.println("Nome: " + Busca.getNome());
                System.out.println("Cor: " + Busca.getCor());
                System.out.println("Número de Marchas: " + Busca.getNumMarchas());
                System.out.println("Número de Portas: " + Busca.getNumPortas());
                System.out.println("Marca: " + Busca.getMarca());
                System.out.println("Ano: " + Busca.getAno());
                System.out.println("========================");
                
        }

        else {
                System.out.println("Veículo não cadastrado!!!");
            }

        _espaço();

        }
        
    

    @Override
    public void Alterar() {
        
        System.out.println("----- Alteração de Veículos -----");
        System.out.println("Digite o número do chassi do veículo a ser alterado:");
        String chassiAlterar = input.nextLine();
        _espaço();

        Veiculo Busca = _Buscalista(chassiAlterar);
        if (Busca != null) {
                System.out.println("Funcionário encontrado!!!");

                while (true) {

                System.out.println("Qual dado vc deseja alterar? \n" +  
                "1 - Nome\n" +
                "2 - Cor\n" +
                "3 - Número de Marchas\n" +
                "4 - Número de Portas\n" +
                "5 - Marca\n" +
                "6 - Ano\n" +
                "7 - Número do Chassi\n" +   
                "8 - Sair");
                int escolha = input.nextInt();
                input.nextLine();
                _espaço();




                if (escolha == 1) {
                    System.out.println("Digite o novo nome: ");
                    String novoNome = input.next();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        Busca.setNome(novoNome);
                        System.out.println("Nome alterado com sucesso!!!");
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                    }

                    _espaço();
                }




                else if (escolha == 2) {
                    System.out.println("Digite a nova cor: ");
                    String novaCor = input.next();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        Busca.setCor(novaCor);
                        System.out.println("Cor alterada com sucesso!!!");
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                    }

                    _espaço();
                }





                else if (escolha == 3) {
                    System.out.println("Digite o novo número de marchas: ");
                    int novoNumMarchas = input.nextInt();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        Busca.setNumMarchas(novoNumMarchas);
                        System.out.println("Número de marchas alterado com sucesso!!!");
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                    }

                    _espaço();
                }





                else if (escolha == 4) {
                    System.out.println("Digite o novo número de portas: ");
                    int novoNumPortas = input.nextInt();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        Busca.setNumPortas(novoNumPortas);
                        System.out.println("Número de portas alterado com sucesso!!!");
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                    }
                    
                    _espaço();
                }


                else if (escolha == 5) {
                    System.out.println("Digite a nova marca: ");
                    String novaMarca = input.next();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        Busca.setMarca(novaMarca);
                        System.out.println("Marca alterada com sucesso!!!");
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                    }
                    
                    _espaço();
                }


                else if (escolha == 6) {
                    System.out.println("Digite o novo ano: ");
                    int novoAno = input.nextInt();
                    input.nextLine();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        Busca.setAno(novoAno);
                        System.out.println("Ano alterado com sucesso!!!");
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                    }

                    _espaço();
                }

                else if (escolha == 7) {
                    System.out.println("Digite o novo número do chassi: ");
                    String novoNumChassi = input.nextLine();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        Busca.setNumChassi(novoNumChassi);
                        System.out.println("Número do chassi alterado com sucesso!!!");
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                    }

                    _espaço();
                }

                else if (escolha == 8) {
                    System.out.println("Saindo do menu de alteração...");
                    _espaço();
                    break;
                }

                else {
                    System.out.println("Opção inválida!!!");
                    _espaço();
                    break;
                }

                
            }
        }

        else {
                System.out.println("Veículo não cadastrado!!!");
                _espaço();
            }    
    }



    @Override
    public void Remocao() {
        
        System.out.println("----- Remoção de Veículos -----");
        System.out.println("Digite o número do chassi do veículo a ser removido:");
        String chassiRemover = input.nextLine();
        _espaço();

        Veiculo Busca = _Buscalista(chassiRemover);
        if (Busca != null) {
                System.out.println("Veículo encontrado!!!");
                System.out.println("Confirma a remoção(s/n)?");
                String confirma = input.nextLine();

                if (confirma.equals("s")){ 
                    Veiculos.remove(Busca);
                    System.out.println("Veículo removido com sucesso!!!");
                }
                else {
                    System.out.println("Remoção cancelada!!!");
                }    

                _espaço();
        }

        else {
                System.out.println("Veículo não cadastrado!!!");
                _espaço();
        }
        
    }



    @Override
    public void Listar() {
        System.out.println("----- Lista de Veículos -----");

        if (Veiculos.isEmpty()) {
            System.out.println("Nenhum veículo cadastrado!!!");
        }

        else {
            for (Veiculo veiculo : Veiculos) {
                System.out.println("========================");
                System.out.println("Número do Chassi: " + veiculo.getNumChassi());
                System.out.println("Nome: " + veiculo.getNome());
                System.out.println("Cor: " + veiculo.getCor());
                System.out.println("Número de Marchas: " + veiculo.getNumMarchas());
                System.out.println("Número de Portas: " + veiculo.getNumPortas());
                System.out.println("Marca: " + veiculo.getMarca());
                System.out.println("Ano: " + veiculo.getAno());
                System.out.println("========================");
                _espaço();
            }
        }

        _espaço();
    }

}
