import java.util.ArrayList;
import java.util.Scanner;

public class Venda implements Modulacao {
    
    private int idCompra;
    private String data;
    private double valor;
    private Cliente cliente;
    private Funcionario funcionario;
    private Veiculo veiculo;
    

    ArrayList<Venda> Vendas = new ArrayList<>();
    Scanner input = new Scanner(System.in);

    public Venda() {
        idCompra = 0;
    }


    protected int getIdCompra() {
        return idCompra;
    }

    protected void setIdCompra(int idCompra) {
        this.idCompra = idCompra;
    }

    protected String getData() {
        return data;
    }

    protected void setData(String data) {
        this.data = data;
    }

    protected double getValor() {
        return valor;
    }

    protected void setValor(double valor) {
        this.valor = valor;
    }

    protected Cliente getCliente() {
        return cliente;
    }

    protected void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    protected Funcionario getFuncionario() {
        return funcionario;
    }

    protected void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    protected Veiculo getVeiculo() {
        return veiculo;
    }

    protected void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }



    private void _espaço() {
        for (int i = 0; i < 3; i++) {
            System.out.println("");
        }
    }

    private Venda _Buscalista(int idBusca) {

        if (Vendas.isEmpty()) {
            System.out.println("Nenhuma venda cadastrada!!!");
            return null;    
        }

        else {
            for (Venda venda : Vendas) {
                if (venda.getIdCompra() == idBusca) {
                    return  venda;
                }
            }

            return null;
        }
    }

    @Override
    public void Cadastro() {
        System.out.println("----- Cadastro de Vendas -----");
        System.out.println("");

        Venda novaVenda = new Venda();

        System.out.println("Digite o cpf do cliente:");
        String cpf = input.nextLine();
        cliente = Cliente._Buscalista(cpf);

        if (cliente == null) {
            System.out.println("Cliente não encontrado. Cancelando cadastro de venda.");
            _espaço();
            return;
        }
        
        else {
            novaVenda.setCliente(cliente);
        }
        

        System.out.println("Digite a matrícula do funcionário:");
        int matricula = input.nextInt();
        funcionario = Funcionario._Buscalista(matricula);

        if (funcionario == null) {
            System.out.println("Funcionário não encontrado. Cancelando cadastro de venda.");
            _espaço();
            return;
        }
        
        else {
            novaVenda.setFuncionario(funcionario);
            input.nextLine();
        }
        
        System.out.println("Digite o número do chassi do veículo:");
        String nchassi = input.nextLine();
        veiculo = Veiculo._Buscalista(nchassi);
        if (veiculo == null) {
            System.out.println("Veículo não encontrado. Cancelando cadastro de venda.");
            _espaço();
            return;
        }
        
        else {
            novaVenda.setVeiculo(veiculo);
        }

        System.out.print("Digite a data da venda: ");
        data = input.nextLine();
        novaVenda.setData(data);

        System.out.print("Digite o valor da venda: ");
        valor = input.nextDouble();
        novaVenda.setValor(valor);
        input.nextLine(); 
        
        Vendas.add(this);
        novaVenda.setIdCompra(this.idCompra+1);
        System.out.println("Venda cadastrada com sucesso!!!");        
        _espaço();
    }

    @Override
    public void Consulta() {
        
        System.out.println("----- Consulta de Vendas -----");
        System.out.println("");
        System.out.println("Digite o ID da venda para busca:");
        int idBusca = input.nextInt();
        input.nextLine();

        Venda busca = _Buscalista(idBusca);
        if (busca != null) {
            System.out.println("Venda encontrada!!!");
            System.out.println("====================================== ");
            System.out.println("ID da Compra: " + busca.getIdCompra());
            System.out.println("Data da Compra: " + busca.getData());
            System.out.println("Valor da Compra: " + busca.getValor());
            System.out.println("Cliente: " + busca.getCliente().getNome());
            System.out.println("Funcionário: " + busca.getFuncionario().getNome());
            System.out.println("Veículo: " + busca.getVeiculo().getNome());
            System.out.println("Npmero do Chassi: " + busca.getVeiculo().getNumChassi());
            System.out.println("======================================");
            _espaço();
        }

        else {
            System.out.println("Venda não encontrada!!!");
            _espaço();
        }
    }        



    @Override
    public void Alterar() {
        
        System.out.println("----- Alteração de Vendas -----");
        System.out.println("");
        System.out.print("Digite o ID da compra para busca: ");
        int idBusca = input.nextInt();
        input.nextLine();
        
        Venda busca = _Buscalista(idBusca);
        if (busca != null) {

                System.out.println("Funcionário encontrado!!!");
                while (true) {

                System.out.println("Qual dado vc deseja alterar? \n" +  
                "1 - Data da Compra\n" +
                "2 - Valor da Compra\n" +
                "3- Cliente\n" +
                "4- Funcionário\n" +
                "5- Veículo\n" +
                "6 - Sair");

                int escolha = input.nextInt();
                input.nextLine();
                _espaço();



                if (escolha == 1) {
                    System.out.println("Digite a nova data: ");
                    String novadata = input.nextLine();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        busca.setData(novadata);
                        System.out.println("Data da compra alterada com sucesso!!!");
                        _espaço();
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                        _espaço();
                    }
                }




                else if (escolha == 2) {
                    System.out.println("Digite o novo valor: ");
                    double novovalor = input.nextDouble();
                    input.nextLine();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        busca.setValor(novovalor);
                        System.out.println("Valor da compra alterado com sucesso!!!");
                        _espaço();
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                        _espaço();
                    }
                }





                else if (escolha == 3) {
                    System.out.println("Digite o novo cliente (cpf): ");
                    String novoclienteCpf = input.nextLine();
                    Cliente novocliente = Cliente._Buscalista(novoclienteCpf);

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        busca.setCliente(novocliente);
                        System.out.println("Cliente alterado com sucesso!!!");
                        _espaço();
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                        _espaço();
                    }
                }





                else if (escolha == 4) {
                    System.out.println("Digite o novo funcionário (matrícula): ");
                    int novofuncionarioMatricula = input.nextInt();
                    Funcionario novofuncionario = Funcionario._Buscalista(novofuncionarioMatricula);
                    input.nextLine();

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        busca.setFuncionario(novofuncionario);
                        System.out.println("Funcionário alterado com sucesso!!!");
                        _espaço();
                    }
                    else {
                        System.out.println("Alteração cancelada!!!");
                        _espaço();
                    }  
                }


                else if (escolha == 5) {
                    System.out.println("Digite o novo veículo (número do chassi): ");
                    String novoveiculoChassi = input.nextLine();
                    Veiculo novoveiculo = Veiculo._Buscalista(novoveiculoChassi);

                    System.out.println("Confirma a alteração(s/n)?");
                    String confirma = input.nextLine();

                    if (confirma.equals("s")){ 
                        busca.setVeiculo(novoveiculo);
                        System.out.println("Veículo alterado com sucesso!!!");
                        _espaço();
                    }

                    else {
                        System.out.println("Alteração cancelada!!!");
                        _espaço();
                    }
                       

                }

                else if (escolha == 6) {
                    System.out.println("Saindo do menu de alteração...");
                    _espaço();
                    break;
                }

                else {
                    System.out.println("Opção inválida!!!");
                    _espaço();
                    break;
                }

                
            }
        }

        else {
                System.out.println("Venda não cadastrada!!!");
                _espaço();
            }
        
    }   


    @Override
    public void Remocao() {
        
        System.out.println("----- Remoção de Vendas -----");
        System.out.println("Digite o ID da compra para a busca:");
        int idBusca = input.nextInt();
        input.nextLine();
        _espaço();

        Venda busca = _Buscalista(idBusca);
        if (busca != null) {

            System.out.println("Venda encontrada!!!");
            System.out.println("Confirma a remoção(s/n)?");
            String confirma = input.nextLine();

            if (confirma.equals("s")){
                Vendas.remove(busca);
                System.out.println("Venda removida com sucesso!!!");
                _espaço();
            }

            else {
                System.out.println("Remoção cancelada!!!");
                _espaço();
            }
        }

        else {
            System.out.println("Venda não encontrada!!!");
            _espaço();
        }
        
    }

    @Override
    public void Listar() {
        
        System.out.println("----- Lista de Vendas -----");
        System.out.println("");

        if (Vendas.isEmpty()) {
            System.out.println("Nenhuma venda cadastrada!!!");
            _espaço();
            return;
        }

        for (Venda venda : Vendas) {
            System.out.println("======================================");
            System.out.println("ID da Compra: " + venda.getIdCompra());
            System.out.println("Data da Compra: " + venda.getData());
            System.out.println("Valor da Compra: " + venda.getValor());
            System.out.println("Cliente: " + venda.getCliente().getNome());
            System.out.println("Funcionário: " + venda.getFuncionario().getNome());
            System.out.println("Veículo: " + venda.getVeiculo().getNome());
            System.out.println("Número do Chassi: " + venda.getVeiculo().getNumChassi());
            System.out.println("=======================================");
            _espaço();
        }

        _espaço();
    }

}
